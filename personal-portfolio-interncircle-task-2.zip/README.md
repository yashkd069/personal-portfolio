# Personal Portfolio Landing Page

A responsive personal developer portfolio created for the InternCircle Web Development Internship Task 2.

## Features
- Semantic HTML5 structure
- Responsive design for mobile, tablet and desktop
- CSS Flexbox and CSS Grid
- About, Skills, Projects and Contact sections
- Responsive navigation menu using JavaScript
- Clean, accessible layout

## Technologies
- HTML5
- CSS3
- JavaScript

## Run locally
Open `index.html` in a web browser.

## Before publishing
Replace `your-email@example.com` and the GitHub/LinkedIn profile links in `index.html` with your real links.
